# मैथिली समाचार — Complete Cloudflare Pages + D1 Portal

यह demo नहीं, एक working foundation है जिसमें public news portal, reader registration/login, comments moderation, bookmarks, roles, categories/sub-categories, author/editor workflow और subscription records शामिल हैं।

## 1. D1 database

```bash
npx wrangler d1 create maithili-news-db
```
`wrangler.toml` में मिले `database_id` को भरें। फिर:

```bash
npx wrangler d1 execute maithili-news-db --remote --file=schema.sql
```

## 2. पहला Admin

Cloudflare Pages project में secret `SETUP_KEY` बनाइए। Deploy के बाद एक बार:

```bash
curl -X POST https://YOUR-DOMAIN/api/setup \
  -H 'Content-Type: application/json' \
  -H 'X-Setup-Key: YOUR_SETUP_KEY' \
  -d '{"name":"Admin","email":"admin@example.com","password":"CHANGE-ME-123"}'
```
इसके बाद setup endpoint दोबारा admin नहीं बनाएगा।

## 3. D1 binding
Cloudflare Pages → Settings → Functions → D1 database binding:

`DB` → आपकी D1 database

## 4. Roles
- admin: पूरा management
- editor: news review/publish, comments moderation, categories
- author: अपना news लिख/सुधार सकता है; publish करने पर review में जाता है
- reader: register/login, comment, bookmark, like, subscription

## 5. Subscription
Subscription tables और plan/order records तैयार हैं। वास्तविक payment के लिए Razorpay/Stripe credentials और webhook लगाना होगा। अभी payment को fake successful नहीं बनाया गया है।

## 6. Important
Article content अभी plain text को सुरक्षित तरीके से render करता है। यदि rich text editor चाहिए तो बाद में sanitized HTML editor जोड़ा जा सकता है।
