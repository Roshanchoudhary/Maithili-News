PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE COLLATE NOCASE,
 mobile TEXT,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'reader' CHECK(role IN ('admin','editor','author','reader')),
 status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','blocked')),
 avatar_url TEXT,
 bio TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

CREATE TABLE IF NOT EXISTS sessions (
 token TEXT PRIMARY KEY,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 expires_at TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);

CREATE TABLE IF NOT EXISTS categories (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 parent_id INTEGER REFERENCES categories(id) ON DELETE CASCADE,
 name TEXT NOT NULL,
 slug TEXT NOT NULL UNIQUE COLLATE NOCASE,
 description TEXT,
 sort_order INTEGER NOT NULL DEFAULT 0,
 menu_visible INTEGER NOT NULL DEFAULT 1,
 status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','inactive')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_categories_parent ON categories(parent_id);

CREATE TABLE IF NOT EXISTS tags (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 slug TEXT NOT NULL UNIQUE COLLATE NOCASE,
 status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','inactive'))
);

CREATE TABLE IF NOT EXISTS news (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 author_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
 editor_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
 category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
 title TEXT NOT NULL,
 slug TEXT NOT NULL UNIQUE COLLATE NOCASE,
 summary TEXT,
 content TEXT NOT NULL,
 image_url TEXT,
 image_alt TEXT,
 status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','review','published','archived')),
 featured INTEGER NOT NULL DEFAULT 0,
 views INTEGER NOT NULL DEFAULT 0,
 likes INTEGER NOT NULL DEFAULT 0,
 seo_title TEXT,
 seo_description TEXT,
 published_at TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_news_status_date ON news(status,published_at);
CREATE INDEX IF NOT EXISTS idx_news_category ON news(category_id);
CREATE INDEX IF NOT EXISTS idx_news_author ON news(author_id);

CREATE TABLE IF NOT EXISTS news_tags (
 news_id INTEGER NOT NULL REFERENCES news(id) ON DELETE CASCADE,
 tag_id INTEGER NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
 PRIMARY KEY(news_id,tag_id)
);

CREATE TABLE IF NOT EXISTS comments (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 news_id INTEGER NOT NULL REFERENCES news(id) ON DELETE CASCADE,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 parent_id INTEGER REFERENCES comments(id) ON DELETE CASCADE,
 comment TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_comments_news ON comments(news_id,status);

CREATE TABLE IF NOT EXISTS comment_likes (
 comment_id INTEGER NOT NULL REFERENCES comments(id) ON DELETE CASCADE,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 PRIMARY KEY(comment_id,user_id)
);

CREATE TABLE IF NOT EXISTS news_likes (
 news_id INTEGER NOT NULL REFERENCES news(id) ON DELETE CASCADE,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 PRIMARY KEY(news_id,user_id)
);

CREATE TABLE IF NOT EXISTS bookmarks (
 news_id INTEGER NOT NULL REFERENCES news(id) ON DELETE CASCADE,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(news_id,user_id)
);

CREATE TABLE IF NOT EXISTS plans (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 slug TEXT NOT NULL UNIQUE COLLATE NOCASE,
 price_paise INTEGER NOT NULL DEFAULT 0,
 duration_days INTEGER NOT NULL,
 description TEXT,
 active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS subscriptions (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 plan_id INTEGER NOT NULL REFERENCES plans(id),
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','active','expired','cancelled')),
 provider TEXT,
 provider_order_id TEXT,
 provider_payment_id TEXT,
 starts_at TEXT,
 ends_at TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_subscriptions_user ON subscriptions(user_id,status);

CREATE TABLE IF NOT EXISTS newsletter_subscribers (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 email TEXT NOT NULL UNIQUE COLLATE NOCASE,
 status TEXT NOT NULL DEFAULT 'active',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS site_settings (
 key TEXT PRIMARY KEY,
 value TEXT NOT NULL
);

INSERT OR IGNORE INTO plans(name,slug,price_paise,duration_days,description) VALUES
('मासिक सदस्यता','monthly',9900,30,'Premium सामग्रीक मासिक पहुँच'),
('वार्षिक सदस्यता','yearly',99900,365,'Premium सामग्रीक वार्षिक पहुँच');
INSERT OR IGNORE INTO site_settings(key,value) VALUES
('site_name','मैथिली समाचार'),
('site_tagline','मैथिली भाषा मे विश्वसनीय समाचार'),
('comments_enabled','1'),
('registration_enabled','1');
