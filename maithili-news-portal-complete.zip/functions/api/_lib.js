const enc = new TextEncoder();

export function json(data,status=200,extra={}){return new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...extra}})}
export async function body(req){try{return await req.json()}catch{return {}}}
export function cookie(req,name){const raw=req.headers.get('Cookie')||''; const m=raw.match(new RegExp('(?:^|;\\s*)'+name.replace(/[.*+?^${}()|[\\]\\]/g,'\\$&')+'=([^;]*)')); return m?decodeURIComponent(m[1]):null}
export function setCookie(token,maxAge=60*60*24*7){return `session=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`}
export function clearCookie(){return 'session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0'}
export async function hashPassword(password){const salt=crypto.getRandomValues(new Uint8Array(16));const key=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveBits']);const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations:120000,hash:'SHA-256'},key,256);return `pbkdf2$120000$${b64(salt)}$${b64(new Uint8Array(bits))}`}
export async function verifyPassword(password,stored){const [kind,it,saltS,hashS]=String(stored||'').split('$');if(kind!=='pbkdf2')return false;const salt=unb64(saltS);const key=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveBits']);const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt,iterations:Number(it),hash:'SHA-256'},key,256);return timingSafe(new Uint8Array(bits),unb64(hashS))}
function b64(bytes){let s='';bytes.forEach(x=>s+=String.fromCharCode(x));return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')}
function unb64(s){s=s.replace(/-/g,'+').replace(/_/g,'/');while(s.length%4)s+='=';const bin=atob(s);return Uint8Array.from(bin,c=>c.charCodeAt(0))}
function timingSafe(a,b){if(a.length!==b.length)return false;let x=0;for(let i=0;i<a.length;i++)x|=a[i]^b[i];return x===0}
export async function createSession(db,userId){const token=b64(crypto.getRandomValues(new Uint8Array(32)));await db.prepare("INSERT INTO sessions(token,user_id,expires_at) VALUES(?,?,datetime('now','+7 days'))").bind(token,userId).run();return token}
export async function auth(req,env){const token=cookie(req,'session');if(!token)return null;return (await env.DB.prepare("SELECT u.id,u.name,u.email,u.mobile,u.role,u.status,u.avatar_url,u.bio FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires_at>datetime('now') AND u.status='active'").bind(token).first())||null}
export function requireRole(user,roles){return !!user && roles.includes(user.role)}
export function slugify(v){return String(v||'').normalize('NFKD').toLowerCase().trim().replace(/[^a-z0-9\s-]/g,'').replace(/\s+/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'')}
export function cleanUser(u){if(!u)return null;const {password_hash,...safe}=u;return safe}
